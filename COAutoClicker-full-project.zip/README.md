# CO Auto Clicker

A simple Android accessibility-based tap helper. You choose a screen coordinate and interval; Android requires you to enable the accessibility service manually in Settings. Test coordinates carefully and stop clicking before switching screens.

## Build

The GitHub Actions workflow builds a debug APK and uploads it as an artifact named `COAutoClicker-debug-apk`.
