package com.example.coautoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class ClickAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var tapX = 0
    private var tapY = 0
    private var intervalMs = 1000L

    private val clickTask = object : Runnable {
        override fun run() {
            if (!running) return
            val width = resources.displayMetrics.widthPixels
            val height = resources.displayMetrics.heightPixels
            if (tapX in 0 until width && tapY in 0 until height) {
                val path = Path().apply { moveTo(tapX.toFloat(), tapY.toFloat()) }
                val gesture = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
                    .build()
                dispatchGesture(gesture, null, null)
            } else {
                running = false
                return
            }
            handler.postDelayed(this, intervalMs)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        stop()
    }

    override fun onDestroy() {
        stop()
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun start(x: Int, y: Int, interval: Long) {
        stop()
        tapX = x
        tapY = y
        intervalMs = interval.coerceAtLeast(100L)
        running = true
        handler.post(clickTask)
    }

    private fun stop() {
        running = false
        handler.removeCallbacks(clickTask)
    }

    companion object {
        @Volatile private var instance: ClickAccessibilityService? = null

        fun startClicking(x: Int, y: Int, intervalMs: Long): Boolean {
            val service = instance ?: return false
            service.start(x, y, intervalMs)
            return true
        }

        fun stopClicking() {
            instance?.stop()
        }
    }
}
