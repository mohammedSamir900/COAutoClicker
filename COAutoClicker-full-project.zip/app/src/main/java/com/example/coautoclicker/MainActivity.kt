package com.example.coautoclicker

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var xInput: EditText
    private lateinit var yInput: EditText
    private lateinit var intervalInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "CO Auto Clicker"
            textSize = 26f
            gravity = Gravity.CENTER
        }, matchWidth())

        root.addView(TextView(this).apply {
            text = "Choose the screen coordinate to tap. Enable the accessibility service before starting."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(18))
        }, matchWidth())

        xInput = field("X coordinate", "500")
        yInput = field("Y coordinate", "500")
        intervalInput = field("Interval in milliseconds (minimum 100)", "1000")
        root.addView(xInput, matchWidth())
        root.addView(yInput, matchWidth())
        root.addView(intervalInput, matchWidth())

        root.addView(button("Open Accessibility Settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, matchWidth())

        root.addView(button("Start Auto Click") {
            val x = xInput.text.toString().toIntOrNull()
            val y = yInput.text.toString().toIntOrNull()
            val interval = intervalInput.text.toString().toLongOrNull()
            if (x == null || y == null || interval == null || x < 0 || y < 0 || interval < 100L) {
                Toast.makeText(this, "Enter valid X/Y values and an interval of at least 100 ms.", Toast.LENGTH_LONG).show()
                return@button
            }
            if (!ClickAccessibilityService.startClicking(x, y, interval)) {
                Toast.makeText(this, "Enable CO Auto Clicker in Accessibility Settings first.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Auto click started. Return to the target app; stop it here first when needed.", Toast.LENGTH_LONG).show()
            }
        }, matchWidth())

        root.addView(button("Stop Auto Click") {
            ClickAccessibilityService.stopClicking()
            Toast.makeText(this, "Auto click stopped.", Toast.LENGTH_SHORT).show()
        }, matchWidth())

        root.addView(TextView(this).apply {
            text = "Safety tip: test with a harmless screen first. Coordinates are screen pixels and may differ by device or orientation."
            textSize = 13f
            setPadding(0, dp(18), 0, 0)
        }, matchWidth())

        setContentView(root)
    }

    private fun field(hintText: String, defaultValue: String): EditText = EditText(this).apply {
        hint = hintText
        setSingleLine(true)
        inputType = android.text.InputType.TYPE_CLASS_NUMBER
        setText(defaultValue)
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        setOnClickListener { action() }
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
